const searchInput = document.querySelector('input[name="Search"]');
const animalInfoContent = document.getElementById('animal-info-content');
const animalImageContainer = document.getElementById('animal-image-container');
const conditionalContent = document.getElementById('conditional-content');

const isServer = window.location.protocol.startsWith('http');

if (isServer) {
    searchInput.addEventListener('input', fetchAnimalInfo);
} else {
    conditionalContent.style.display = 'none';
}

function fetchAnimalInfo() {
    const searchValue = searchInput.value.trim(); 

    if (searchValue) {
        const apiKey = 'live_N5pyhXfUI3mJszlZ1Zq86mOjI3MOL2GvInR9qyispkKyJz4Z7qvfOi41PUNMzV4h';
        const apiUrl = `https://api.thecatapi.com/v1/breeds/search?q=${searchValue}`;

        fetch(apiUrl, {
            headers: {
                'x-api-key': apiKey,
            },
        })
        .then((response) => response.json())
        .then((data) => {
            if (data.length > 0) {
                animalInfoContent.innerHTML = ''; 
                animalImageContainer.innerHTML = '';

                data.forEach((animalInfo) => {
                    const breedId = animalInfo.id;

                    const animalContainer = document.createElement('div');
                    animalContainer.classList.add('animal-container');

                    const infoDiv = document.createElement('div');
                    infoDiv.innerHTML = `
                        <h3>${animalInfo.name}</h3>
                        <p>Origin: ${animalInfo.origin}</p>
                        <p>Temperament: ${animalInfo.temperament}</p>
                        <p>Life Span: ${animalInfo.life_span}</p>
                    `;
                    animalContainer.appendChild(infoDiv);

                    fetch(`https://api.thecatapi.com/v1/images/search?breed_id=${breedId}`, {
                        headers: {
                            'x-api-key': apiKey,
                        },
                    })
                    .then((response) => response.json())
                    .then((images) => {
                        if (images.length > 0) {
                            const imageUrl = images[0].url;
                            const image = document.createElement('img');
                            image.src = imageUrl;
                            image.alt = animalInfo.name;
                            animalContainer.appendChild(image);
                        }
                    })
                    .catch((error) => {
                        console.error('Error fetching animal images:', error);
                    });

                    animalInfoContent.appendChild(animalContainer);
                });
            } else {
                animalInfoContent.innerHTML = 'No animals found for your search.';
                animalImageContainer.innerHTML = '';
            }
        })
        .catch((error) => {
            console.error('Error fetching animal information:', error);
        });
    } else {
        animalInfoContent.innerHTML = '';
        animalImageContainer.innerHTML = '';
    }
}
