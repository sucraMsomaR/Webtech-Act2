const searchInput = document.querySelector('input[name="Search"]');
const dogInfoContent = document.getElementById('dog-info-content');
const dogImageContainer = document.getElementById('dog-image-container');
const conditionalContent = document.getElementById('conditional-content');

const isServer = window.location.protocol.startsWith('http');

if (isServer) {
    searchInput.addEventListener('input', fetchDogInfo);
} else {
    conditionalContent.style.display = 'none';
}

function fetchDogInfo() {
    const searchValue = searchInput.value.trim(); 

    if (searchValue) {
        const apiKey = 'live_fIVwZ4juPQuIRcl46GI8YBPigJgcn17wFTPDwR9V0XuEAvXUWEJFusOYKyxXT8Ti';
        const apiUrl = `https://api.thedogapi.com/v1/breeds/search?q=${searchValue}`;

        fetch(apiUrl, {
            headers: {
                'x-api-key': apiKey,
            },
        })
        .then((response) => response.json())
        .then((data) => {
            if (data.length > 0) {
                dogInfoContent.innerHTML = ''; 
                dogImageContainer.innerHTML = '';

                data.forEach((dogInfo) => {
                    const breedId = dogInfo.id;

                    const breedContainer = document.createElement('div');
                    breedContainer.classList.add('breed-container');

                    const infoDiv = document.createElement('div');
                    infoDiv.innerHTML = `
                        <h3>${dogInfo.name}</h3>
                        <p>Origin: ${dogInfo.origin}</p>
                        <p>Temperament: ${dogInfo.temperament}</p>
                        <p>Life Span: ${dogInfo.life_span}</p>
                    `;
                    breedContainer.appendChild(infoDiv);

                    fetch(`https://api.thedogapi.com/v1/images/search?breed_id=${breedId}`, {
                        headers: {
                            'x-api-key': apiKey,
                        },
                    })
                    .then((response) => response.json())
                    .then((images) => {
                        if (images.length > 0) {
                            const imageUrl = images[0].url;
                            const image = document.createElement('img');
                            image.src = imageUrl;
                            image.alt = dogInfo.name;
                            breedContainer.appendChild(image);
                        }
                    })
                    .catch((error) => {
                        console.error('Error fetching dog images:', error);
                    });

                    dogInfoContent.appendChild(breedContainer);
                });
            } else {
                dogInfoContent.innerHTML = 'No dogs found for your search.';
                dogImageContainer.innerHTML = '';
            }
        })
        .catch((error) => {
            console.error('Error fetching dog information:', error);
        });
    } else {
        dogInfoContent.innerHTML = '';
        dogImageContainer.innerHTML = '';
    }
}
