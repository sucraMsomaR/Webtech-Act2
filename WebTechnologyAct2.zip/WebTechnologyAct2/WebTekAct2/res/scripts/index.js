document.getElementById("dogs-button").addEventListener("click", function() {
    document.querySelector(".content").classList.add("fade-out");

    setTimeout(function() {
        window.location.href = "dogs.html";
    }, 500);
});

document.getElementById("cats-button").addEventListener("click", function() {
    document.querySelector(".content").classList.add("fade-out");

    setTimeout(function() {
        window.location.href = "cat.html"; 
    }, 500);
});
