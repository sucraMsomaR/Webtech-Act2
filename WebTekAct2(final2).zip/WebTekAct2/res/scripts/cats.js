// Done by Marcus Ramos
// This section defines variables and sets up event listeners.

// Get the input element with the name "Search".
const searchInput = document.querySelector('input[name="Search"]');
// Get the elements by their IDs.
const animalInfoContent = document.getElementById('animal-info-content');
const animalImageContainer = document.getElementById('animal-image-container');
const conditionalContent = document.getElementById('conditional-content');

// Check if the website is served over HTTP.
const isServer = window.location.protocol.startsWith('http');

// If the website is served over HTTP, add an event listener for input changes in the search input.
if (isServer) {
    searchInput.addEventListener('input', fetchAnimalInfo);
} else {
    // If not served over HTTP, hide the "conditional-content" element.
    conditionalContent.style.display = 'none';
}

// Function to fetch catinformation based on the search input.
function fetchAnimalInfo() {
    const searchValue = searchInput.value.trim(); 

    if (searchValue) {
        // API key for authentication.
        const apiKey = 'live_N5pyhXfUI3mJszlZ1Zq86mOjI3MOL2GvInR9qyispkKyJz4Z7qvfOi41PUNMzV4h';
        // Construct the API URL for searching dog breeds based on the search value.
        const apiUrl = `https://api.thecatapi.com/v1/breeds/search?q=${searchValue}`;

         // Fetch data from the API using the constructed URL and API key.
        fetch(apiUrl, {
            headers: {
                'x-api-key': apiKey,
            },
        })
        .then((response) => response.json())
        .then((data) => {
            if (data.length > 0) {
                // Clear existing content in the "catInfoContent" and "catImageContainer".
                animalInfoContent.innerHTML = ''; 
                animalImageContainer.innerHTML = '';
                
                 // Loop through the retrieved data and create elements to display dog information.
                data.forEach((animalInfo) => {
                    const breedId = animalInfo.id;

                    // Create a container for each cat breed.
                    const animalContainer = document.createElement('div');
                    animalContainer.classList.add('animal-container');

                    // Create an info div with cat details.
                    const infoDiv = document.createElement('div');
                    infoDiv.innerHTML = `
                        <h3>${animalInfo.name}</h3>
                        <p>Origin: ${animalInfo.origin}</p>
                        <p>Temperament: ${animalInfo.temperament}</p>
                        <p>Life Span: ${animalInfo.life_span}</p>
                    `;
                    animalContainer.appendChild(infoDiv);

                    // Fetch images for the cat breed using its ID.
                    fetch(`https://api.thecatapi.com/v1/images/search?breed_id=${breedId}`, {
                        headers: {
                            'x-api-key': apiKey,
                        },
                    })
                    .then((response) => response.json())
                    .then((images) => {
                        if (images.length > 0) {
                            // If images are available, create an image element and add it to the breed container.
                            const imageUrl = images[0].url;
                            const image = document.createElement('img');
                            image.src = imageUrl;
                            image.alt = animalInfo.name;
                            animalContainer.appendChild(image);
                        }
                    })
                    .catch((error) => {
                        console.error('Error fetching animal images:', error);
                    });

                    // Add the breed container to the "animalInfoContent".
                    animalInfoContent.appendChild(animalContainer);
                });
            } else {
                // If no cats are found for the search, display a message.
                animalInfoContent.innerHTML = 'No cat found for your search.';
                animalImageContainer.innerHTML = '';
            }
        })
        .catch((error) => {
            console.error('Error fetching animal information:', error);
        });
    } else {
        // Clear content in "animalInfoContent" and "animalImageContainer" if there is no search value.
        animalInfoContent.innerHTML = '';
        animalImageContainer.innerHTML = '';
    }
}

// Done by Lindolf Agustin
// This section adds video iframes to specific containers when the page is loaded.

// Event listener for the "load" event of the window.
window.addEventListener('load', () => {
    const catVideoContainer1 = document.getElementById('cat-video-1');
    const catVideoContainer2 = document.getElementById('cat-video-2');
    const catVideoContainer3 = document.getElementById('cat-video-3');

    const catVideoId1 = '35lcsFGu_I0';
    const catVideoId2 = '5P6JohWZFQY';
    const catVideoId3 = '4CmKWyNuj-I';

    // If the containers exist, create and add video iframes to them.
    if (catVideoContainer1) {
        const catIframe1 = createVideoIframe(catVideoId1);
        catVideoContainer1.appendChild(catIframe1);
    }

    if (catVideoContainer2) {
        const catIframe2 = createVideoIframe(catVideoId2);
        catVideoContainer2.appendChild(catIframe2);
    }

    if (catVideoContainer3) {
        const catIframe3 = createVideoIframe(catVideoId3);
        catVideoContainer3.appendChild(catIframe3);
    }
});

// Function to create a video iframe with the specified video ID.
function createVideoIframe(videoId) {
    const iframe = document.createElement('iframe');
    iframe.setAttribute('width', '560');
    iframe.setAttribute('height', '400');
    iframe.setAttribute('src', `https://www.youtube.com/embed/${videoId}?autoplay=0`);
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
    iframe.setAttribute('allowfullscreen', '');

    return iframe;
}