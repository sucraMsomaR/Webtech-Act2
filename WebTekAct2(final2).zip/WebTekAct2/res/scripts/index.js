// Event listener for the "dogs-button" click event.
document.getElementById("dogs-button").addEventListener("click", function() {
    // Add a "fade-out" class to the element with class "content".
    document.querySelector(".content").classList.add("fade-out");

    // Set a timeout to redirect to the "dogs.html" page after 500 milliseconds (0.5 seconds).
    setTimeout(function() {
        window.location.href = "dogs.html";
    }, 500);
});

// Event listener for the "cats-button" click event.
document.getElementById("cats-button").addEventListener("click", function() {
    // Add a "fade-out" class to the element with class "content".
    document.querySelector(".content").classList.add("fade-out");

    // Set a timeout to redirect to the "cat.html" page after 500 milliseconds (0.5 seconds).
    setTimeout(function() {
        window.location.href = "cat.html"; 
    }, 500);
});

// Get the element with class "content".
const contentElement = document.querySelector('.content');

// Set a timeout to add a "fade-in" class to the "content" element after 100 milliseconds (0.1 seconds).
setTimeout(() => {
    contentElement.classList.add('fade-in');
}, 100); // 100 milliseconds (0.1 seconds) delay
