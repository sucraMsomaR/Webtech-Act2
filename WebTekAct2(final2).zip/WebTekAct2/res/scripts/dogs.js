// Done by Marcus Ramos
// This section defines variables and sets up event listeners.

// Get the input element with the name "Search".
const searchInput = document.querySelector('input[name="Search"]');
// Get the elements by their IDs.
const dogInfoContent = document.getElementById('dog-info-content');
const dogImageContainer = document.getElementById('dog-image-container');
const conditionalContent = document.getElementById('conditional-content');

// Check if the website is served over HTTP.
const isServer = window.location.protocol.startsWith('http');

// If the website is served over HTTP, add an event listener for input changes in the search input.
if (isServer) {
    searchInput.addEventListener('input', fetchDogInfo);
} else {
    // If not served over HTTP, hide the "conditional-content" element.
    conditionalContent.style.display = 'none';
}

// Function to fetch dog information based on the search input.
function fetchDogInfo() {
    const searchValue = searchInput.value.trim();

    if (searchValue) {
        // API key for authentication.
        const apiKey = 'live_fIVwZ4juPQuIRcl46GI8YBPigJgcn17wFTPDwR9V0XuEAvXUWEJFusOYKyxXT8Ti';
        // Construct the API URL for searching dog breeds based on the search value.
        const apiUrl = `https://api.thedogapi.com/v1/breeds/search?q=${searchValue}`;

        // Fetch data from the API using the constructed URL and API key.
        fetch(apiUrl, {
            headers: {
                'x-api-key': apiKey,
            },
        })
        .then((response) => response.json())
        .then((data) => {
            if (data.length > 0) {
                // Clear existing content in the "dogInfoContent" and "dogImageContainer".
                dogInfoContent.innerHTML = '';
                dogImageContainer.innerHTML = '';

                // Loop through the retrieved data and create elements to display dog information.
                data.forEach((dogInfo) => {
                    const breedId = dogInfo.id;

                    // Create a container for each dog breed.
                    const breedContainer = document.createElement('div');
                    breedContainer.classList.add('breed-container');

                    // Create an info div with dog details.
                    const infoDiv = document.createElement('div');
                    infoDiv.innerHTML = `
                        <h3>${dogInfo.name}</h3>
                        <p>Origin: ${dogInfo.origin}</p>
                        <p>Temperament: ${dogInfo.temperament}</p>
                        <p>Life Span: ${dogInfo.life_span}</p>
                    `;
                    breedContainer.appendChild(infoDiv);

                    // Fetch images for the dog breed using its ID.
                    fetch(`https://api.thedogapi.com/v1/images/search?breed_id=${breedId}`, {
                        headers: {
                            'x-api-key': apiKey,
                        },
                    })
                    .then((response) => response.json())
                    .then((images) => {
                        if (images.length > 0) {
                            // If images are available, create an image element and add it to the breed container.
                            const imageUrl = images[0].url;
                            const image = document.createElement('img');
                            image.src = imageUrl;
                            image.alt = dogInfo.name;
                            breedContainer.appendChild(image);
                        }
                    })
                    .catch((error) => {
                        console.error('Error fetching dog images:', error);
                    });

                    // Add the breed container to the "dogInfoContent".
                    dogInfoContent.appendChild(breedContainer);
                });
            } else {
                // If no dogs are found for the search, display a message.
                dogInfoContent.innerHTML = 'No dogs found for your search.';
                dogImageContainer.innerHTML = '';
            }
        })
        .catch((error) => {
            console.error('Error fetching dog information:', error);
        });
    } else {
        // Clear content in "dogInfoContent" and "dogImageContainer" if there is no search value.
        dogInfoContent.innerHTML = '';
        dogImageContainer.innerHTML = '';
    }
}

// Done by Lindolf Agustin
// This section adds video iframes to specific containers when the page is loaded.

// Event listener for the "load" event of the window.
window.addEventListener('load', () => {
    const dogVideoContainer1 = document.getElementById('dog-video-1');
    const dogVideoContainer2 = document.getElementById('dog-video-2');
    const dogVideoContainer3 = document.getElementById('dog-video-3');

    const dogVideoId1 = 'JJVFSWHZYjY';
    const dogVideoId2 = 'wST0xNrk-CA';
    const dogVideoId3 = 'vqP453qscMg';

    // If the containers exist, create and add video iframes to them.
    if (dogVideoContainer1) {
        const dogIframe1 = createVideoIframe(dogVideoId1);
        dogVideoContainer1.appendChild(dogIframe1);
    }

    if (dogVideoContainer2) {
        const dogIframe2 = createVideoIframe(dogVideoId2);
        dogVideoContainer2.appendChild(dogIframe2);
    }

    if (dogVideoContainer3) {
        const dogIframe3 = createVideoIframe(dogVideoId3);
        dogVideoContainer3.appendChild(dogIframe3);
    }
});

// Function to create a video iframe with the specified video ID.
function createVideoIframe(videoId) {
    const iframe = document.createElement('iframe');
    iframe.setAttribute('width', '560');
    iframe.setAttribute('height', '400');
    iframe.setAttribute('src', `https://www.youtube.com/embed/${videoId}?autoplay=0`);
    iframe.setAttribute('frameborder', '0');
    iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
    iframe.setAttribute('allowfullscreen', '');

    return iframe;
}
